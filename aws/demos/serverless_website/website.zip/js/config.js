window._config = {
    cognito: {
        userPoolId: 'us-east-1_ImS57Z4Tz', // e.g. us-east-2_uXboG5pAb
        userPoolClientId: '63h67vj5jahlge07ft87o1rl6t', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'us-east-1' // e.g. us-east-2
    },
    api: {
        invokeUrl: 'https://iq549btp4j.execute-api.us-east-1.amazonaws.com/prod' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};
