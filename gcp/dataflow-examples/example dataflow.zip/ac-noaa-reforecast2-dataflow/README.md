# NOAA Reforecast2 Model Extraction Pipeline

This project consists in a Google DataFlow pipeline that pulls specific files from an FTP server of the NOAA that contains files with weather forecast data. 

The pipeline does the following:

![Alt text](http://www.gravizo.com/svg?@startuml;actor%20User;participant%20%22DataFlow%22%20as%20A;participant%20%22NOAA%22%20as%20B;participant%20%22GoogleStorage%22%20as%20C;participant%20%22BigQuery%22%20as%20D;User%20-%3E%20A:%20from%20startDate%20to%20endDate;activate%20A;A%20-%3E%20A:%20Generate%20list%20of%20URLs;A%20-%3E%20C:%20Check%20file%20existence;C%20-%3E%20A:%20Pull%20pre-downloaded%20file%20%28if%20present%29;A%20-%3E%20B:%20Download%20file;A%20--%3E%20C:%20Push%20file%20to%20storage;A%20-%3E%20A:%20Extract%20Statistics;A%20-%3E%20D:%20Push%20Statistics%20%28data_[year]%29;A%20--%3E%20User:%20Done;deactivate%20A;@enduml)

# Running

## Configuration Parameters

You need to provide both the starting date and the ending date of the gathering process when launching the DataFlow job. The other parameters: locations and statistics are taken from local resources files: locations.csv and statistics.txt. To launch the DataFlow pipeline you can use the start_dataflow.sh file.

**Important**: specify the startDate and endDate using the -Dexec.args line of arguments (see bellow). 

### Running locally

You can use the following command to run the pipeline locally. It will use your personal Google credentials to access the google resources (Google Storage, BigQuery, etc). Make sure you have the right privileges (or change the target resources).

```bash
mvn compile exec:java -Dexec.mainClass=com.ivadolabs.ac.noaa.ReForecast2Extract  \
    -Dexec.args="--project=ivadolabs-ac --tempLocation=gs://ivadolabs-ac-temp/tmp --startDate=2018-12-08 --endDate=2018-12-10"
```

### Launch DataFlow

This command will launch the pipeline process within Google's DataFlow framework.

```bash
mvn compile exec:java -Dexec.mainClass=com.ivadolabs.ac.noaa.ReForecast2Extract  \
    -Dexec.args="--runner=DataflowRunner --project=ivadolabs-ac --tempLocation=gs://ivadolabs-ac-temp/tmp --startDate=2018-12-08 --endDate=2018-12-10"  \
    -Pdataflow-runner
```

# Data

The extracted data will be pushed to BigQuery in "ivadolabs-ac"."noaa_reforecast2". The code generates a table per year of data using the following name convention: data_[year].

## Schema

|Column|Type|Description| 
|---|---|---|
|airport|String|IATA Airport code closest to this prediction|
|name|String|Statistic code name (see list [here - pages 9 and 10](https://www.esrl.noaa.gov/psd/forecasts/reforecast2/README.GEFS_Reforecast2.pdf))|
|unit|String|Unit of measure for this value|
|analysis_date|Datetime|Day of the prediction (the day the user would have seen this forecast)|
|valid_date|Datetime|Datetime of the forecast (datetime where the forecast applies)|
|hrs_delta|Integer|Number of hours difference between analysis_date and valid_date|
|latitude|Float|Coordinate of the forecast|
|longitude|Float|Coordinate of the forecast|
|value|Float|prediction value|
|load_time|Datetime|Datetime when this value was stored|

## Sample Requests

Extracts all recorded statistics for a given airport

```sql
select airport, name, analysis_date, valid_date, hrs_delta, value from noaa_reforecast2.data_2018 where airport = 'BOS' order by name, analysis_date, valid_date, hrs_delta;
```

# Design Choices

## DataFlow

We selected dataflow for this project to allow us to reprocess the GRIB2 files easily and extract data in any way we want. The last part of the pipeline converts the Statistic object into a BigQuery TableRow entry. We can easily change this last component to change the persistence format (save to CSV or another database service).

## Google Storage

This pipeline leverages Google Storage as an intermediary persistent cache layer to the actual GRIB2 files gathered from NOAA. This enables the user to reprocess very easily the GRIB2 files without imposing any stress on the NOAA FTP server.

