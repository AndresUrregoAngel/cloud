package com.ivadolabs.ac.noaa;

import com.ivadolabs.ac.noaa.transformer.BigQueryExport;
import com.ivadolabs.ac.noaa.transformer.GRIBExtractor;
import com.ivadolabs.ac.noaa.transformer.GoogleStorageFTPIO;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.options.Validation;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;

public class ReForecast2Extract {

    // using a local defined project name to make sure the user does not create new table when using different Google credentials.
    private static final String PROJECT_ID = "ivadolabs-ac";

    /**
     * Options supported by {@link ReForecast2Extract}.
     *
     * <p>Inherits standard configuration options.
     */
    public interface ReForecast2ExtractOptions extends PipelineOptions {

        @Description("Starting Day for which we want to compile statistics")
        @Validation.Required
        String getStartDate();

        void setStartDate(String value);

        @Description("Last Day for which we want to compile statistics")
        @Validation.Required
        String getEndDate();

        void setEndDate(String value);

    }


    static void run(ReForecast2Extract.ReForecast2ExtractOptions options) throws ParseException, IOException, URISyntaxException {
        Pipeline p = Pipeline.create(options);

        p.apply("Generate files to Download",
                ReForecast2ExtractUtils.generateNOAAFTPUrls(options.getStartDate(), options.getEndDate()))
         .apply("FTP Download/Google Storage sync",
                 new GoogleStorageFTPIO("ivadolabs-ac-weather-data","noaa_reforecast2"))
         .apply("Process GRIB files",
                 new GRIBExtractor())
         .apply("Export to BigQuery",
                 new BigQueryExport(PROJECT_ID, "noaa_reforecast2", "data_"));

        p.run().waitUntilFinish();
    }

    public static void main(String[] args) throws ParseException, IOException, URISyntaxException {
        ReForecast2Extract.ReForecast2ExtractOptions options =
                PipelineOptionsFactory.fromArgs(args).withValidation().as(ReForecast2Extract.ReForecast2ExtractOptions.class);
        ReForecast2Extract.run(options);

    }
}
