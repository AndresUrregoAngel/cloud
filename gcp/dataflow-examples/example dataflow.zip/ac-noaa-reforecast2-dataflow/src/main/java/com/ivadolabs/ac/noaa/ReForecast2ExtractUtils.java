package com.ivadolabs.ac.noaa;

import com.google.common.collect.Lists;
import com.ivadolabs.ac.noaa.domain.Location;
import org.apache.beam.sdk.transforms.Create;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ReForecast2ExtractUtils {

    private static final String INPUT_DATE_FORMAT = "yyyy-MM-dd";

    /**
     * Returns the list of URL to use in order to collect the configured dates and local locations and statistics.
     * The dates are used to generate daily URLs (including end date).
     * @param startDateStr "yyyy-MM-dd" starting date
     * @param endDateStr "yyyy-MM-dd" starting date
     * @return the list of URL to use in order to collect the configured dates and local locations and statistics.
     * @throws IOException
     * @throws ParseException
     * @throws URISyntaxException
     */
    public static Create.Values<String> generateNOAAFTPUrls(String startDateStr, String endDateStr) throws IOException, ParseException, URISyntaxException {
        return Create.of(filenameGenerator(startDateStr, endDateStr).collect(Collectors.toList()));
    }

    /**
     * Reads resource file locations.csv and return a list of Location.
     * @return list of Location from CSV file
     * @throws IOException
     * @throws URISyntaxException
     */
    public static List<Location> getLocations() throws IOException, URISyntaxException {
        return readLinesFromResourceFile("/locations.csv").map(
                line -> {
                    List<String> parts = Arrays.stream(line.split(",")).map(part -> part.replace("\"", "")).collect(Collectors.toList());
                    return new Location(parts.get(0), parts.get(1), Float.parseFloat(parts.get(2)), Float.parseFloat(parts.get(3)));
                }
        ).collect(Collectors.toList());
    }

    static Stream<String> readLinesFromResourceFile(String resourcePath) throws IOException, URISyntaxException {
        return Files.lines(Paths.get(ReForecast2ExtractUtils.class.getResource(resourcePath).toURI()));
    }

    static Calendar convertToCalendar(String inputDateStr) throws ParseException {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new SimpleDateFormat(INPUT_DATE_FORMAT).parse(inputDateStr));
        return cal;
    }

    static Stream<String> filenameGenerator(String startDateStr, String endDateStr) throws IOException, ParseException, URISyntaxException {
        LocalDate start = LocalDate.parse(startDateStr);
        LocalDate end = LocalDate.parse(endDateStr);
        List<String> statistics = ReForecast2ExtractUtils.readLinesFromResourceFile("/statistics.txt").collect(Collectors.toList());

        List<String> noaaFileSuffixes = Lists.newArrayList("", "_t190");

        return noaaFileSuffixes.stream().flatMap(suffix ->
                Stream.iterate(start, date -> date.plusDays(1))
                .limit(ChronoUnit.DAYS.between(start, end) + 1)
                .flatMap(day -> statistics.stream().map(statistic ->
                        String.format("ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/%s/%s%02d/%s%02d%02d00/c00/latlon/%s_%s%02d%02d00_c00%s.grib2",
                            day.getYear(),
                            day.getYear(),
                            day.getMonth().getValue(),
                            day.getYear(),
                            day.getMonth().getValue(),
                            day.getDayOfMonth(),
                            statistic,
                            day.getYear(),
                            day.getMonth().getValue(),
                            day.getDayOfMonth(),
                                suffix)
                        )
                    )
        );

    }

}
