package com.ivadolabs.ac.noaa.domain;

import java.io.Serializable;
import java.text.ParseException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.SignStyle;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.time.temporal.ChronoField.*;

public class GRIBFile implements Serializable {

    private static final Pattern STATISTIC_NAME_EXTRACTOR = Pattern.compile(".*\\/latlon\\/(?<statname>[a-zA-Z]+_[a-zA-Z0-9]+).*");
    private static final Pattern ANALYSIS_DATE_EXTRACTOR = Pattern.compile(".*\\/latlon\\/[a-zA-Z]+_[a-zA-Z0-9]+_(?<analysisdate>[0-9]+).*");

    private final String fileName;
    private final byte[] content;
    private final String statisticName;
    private final ZonedDateTime analylsisDate;
    private final Boolean cached;

    public GRIBFile(String fileName, byte[] content, String statisticName, ZonedDateTime analylsisDate, Boolean cached) {
        this.fileName = fileName;
        this.content = content;
        this.statisticName = statisticName;
        this.analylsisDate = analylsisDate;
        this.cached = cached;
    }

    public String getFileName() {
        return fileName;
    }

    public byte[] getContent() {
        return content;
    }

    public String getStatisticName() {
        return statisticName;
    }

    public ZonedDateTime getAnalylsisDate() {
        return analylsisDate;
    }

    public Boolean isCached() {
        return cached;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GRIBFile gribFile = (GRIBFile) o;
        return Objects.equals(fileName, gribFile.fileName) &&
                Objects.equals(statisticName, gribFile.statisticName) &&
                Objects.equals(analylsisDate, gribFile.analylsisDate) &&
                Objects.equals(cached, gribFile.cached);
    }

    @Override
    public int hashCode() {
        return Objects.hash(fileName, statisticName, analylsisDate, cached);
    }

    public static GRIBFile from(String filename, byte[] content, Boolean cached) throws ParseException {
        Matcher m1 = STATISTIC_NAME_EXTRACTOR.matcher(filename);
        Matcher m2 = ANALYSIS_DATE_EXTRACTOR.matcher(filename);
        if (m1.matches() && m2.matches()) {
            return new GRIBFile(filename,
                    content,
                    m1.group("statname"),
                    parseAnalysisDate(m2.group("analysisdate")),
                    cached
            );
        } else {
            throw new ParseException("Could'nt extract the Statistic name and/or the analysis date using local Regular Expressions", 0);
        }
    }

    private static ZonedDateTime parseAnalysisDate(String analysisDate) {
        return ZonedDateTime.parse(analysisDate.substring(0, 8) + " 00:00:00.000000",
                new DateTimeFormatterBuilder()
                        .appendValue(YEAR, 4, 10, SignStyle.EXCEEDS_PAD)
                        .appendValue(MONTH_OF_YEAR, 2)
                        .appendValue(DAY_OF_MONTH, 2)
                        .appendLiteral(" ")
                        .appendValue(HOUR_OF_DAY, 2)
                        .appendLiteral(":")
                        .appendValue(MINUTE_OF_HOUR, 2)
                        .appendLiteral(":")
                        .appendValue(SECOND_OF_MINUTE, 2)
                        .appendLiteral(".")
                        .appendValue(MILLI_OF_SECOND, 6)
                        .toFormatter()
                        .withZone(ZoneId.of("UTC")));
    }
}
