package com.ivadolabs.ac.noaa.domain;

import java.io.Serializable;

public class Location implements Serializable {

    private final String airportCode;
    private final String name;
    private final Float latitude;
    private final Float longitude;

    public Location(String airportCode, String name, Float latitude, Float longitude) {
        this.airportCode = airportCode;
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getAirportCode() {
        return airportCode;
    }

    public String getName() {
        return name;
    }

    public Float getLatitude() {
        return latitude;
    }

    public Float getLongitude() {
        return longitude;
    }
}
