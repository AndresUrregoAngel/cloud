package com.ivadolabs.ac.noaa.domain;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Objects;

public class Statistic implements Serializable {

    private final String location;
    private final String name;
    private final String unit;

    private final long hoursDelta;

    private final ZonedDateTime analysisDate;
    private final ZonedDateTime validDate;

    private final Float latitude;
    private final Float longitude;
    private final Float value;

    public Statistic(String location, String name, String unit, ZonedDateTime analylsisDate, ZonedDateTime validDate, Float latitude, Float longitude, Float value) {
        this.location = location;
        this.name = name;
        this.unit = unit;
        this.analysisDate = analylsisDate;
        this.validDate = validDate;
        this.latitude = latitude;
        this.longitude = longitude;
        this.value = value;
        this.hoursDelta = ChronoUnit.HOURS.between(analylsisDate, validDate);
    }

    public String getLocation() {
        return location;
    }

    public String getName() {
        return name;
    }

    public String getUnit() {
        return unit;
    }

    public ZonedDateTime getAnalysisDate() {
        return analysisDate;
    }

    public ZonedDateTime getValidDate() {
        return validDate;
    }

    public long getHoursDelta() {
        return hoursDelta;
    }

    public Float getLatitude() {
        return latitude;
    }

    public Float getLongitude() {
        return longitude;
    }

    public Float getValue() {
        return value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Statistic statistic = (Statistic) o;
        return Objects.equals(location, statistic.location) &&
                Objects.equals(name, statistic.name) &&
                Objects.equals(unit, statistic.unit) &&
                Objects.equals(analysisDate, statistic.analysisDate) &&
                Objects.equals(validDate, statistic.validDate) &&
                Objects.equals(latitude, statistic.latitude) &&
                Objects.equals(longitude, statistic.longitude) &&
                Objects.equals(value, statistic.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(location, name, unit, analysisDate, validDate, latitude, longitude, value);
    }

    @Override
    public String toString() {
        return "Statistic{" +
                "location='" + location + '\'' +
                ", name='" + name + '\'' +
                ", unit='" + unit + '\'' +
                ", analysisDate=" + analysisDate +
                ", validDate=" + validDate +
                ", hrsDelta=" + hoursDelta +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", value=" + value +
                '}';
    }

    public static Statistic from(GRIBFile file, String location, String unit, ZonedDateTime validDate, Float latitude, Float longitude, Float value) {
        return new Statistic(
                location,
                file.getStatisticName(),
                unit,
                file.getAnalylsisDate(),
                validDate,
                latitude,
                longitude,
                value
        );
    }
}
