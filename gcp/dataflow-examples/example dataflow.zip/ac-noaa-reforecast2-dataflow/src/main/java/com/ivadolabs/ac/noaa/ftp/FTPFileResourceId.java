package com.ivadolabs.ac.noaa.ftp;

import org.apache.beam.sdk.io.fs.ResolveOptions;
import org.apache.beam.sdk.io.fs.ResourceId;

import javax.annotation.Nullable;

public class FTPFileResourceId implements ResourceId {

    private final String ftpPath;
    private final String server;
    private final String filepath;

    public FTPFileResourceId(String ftpPath) {
        this.ftpPath = ftpPath;
        this.server = ftpPath.replace("ftp://", "").split("/")[0];
        this.filepath = ftpPath.replace("ftp://", "").replace(this.server, "");
    }

    @Override
    public ResourceId resolve(String other, ResolveOptions resolveOptions) {
        return null;
    }

    @Override
    public ResourceId getCurrentDirectory() {
        return null;
    }

    @Override
    public String getScheme() {
        return "ftp";
    }

    @Nullable
    @Override
    public String getFilename() {
        return filepath;
    }

    @Override
    public boolean isDirectory() {
        return false;
    }

    @Override
    public String toString() {
        return ftpPath;
    }

    public String getFTPServer() {
        return server;
    }
}
