package com.ivadolabs.ac.noaa.ftp;

import org.apache.beam.sdk.io.FileSystem;
import org.apache.beam.sdk.io.fs.CreateOptions;
import org.apache.beam.sdk.io.fs.MatchResult;
import org.apache.beam.sdk.io.fs.ResourceId;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Straight-forward/Dummy FTP implementation of FileSystem.
 *
 * This implementation assumes "anonymous" access is available on target FTP server.
 * Also, it always uses BINARY mode to transfer files.
 */
public class FTPFileSystem extends FileSystem {

    private static final Logger LOG = LoggerFactory.getLogger(FTPFileSystem.class);

    @Override
    protected List<MatchResult> match(List specs) throws IOException {
        return (List<MatchResult>)specs.stream().map(item -> {
            MatchResult.Metadata.Builder ret = MatchResult.Metadata.builder()
                    // Lie on size bytes here. It does not matter because this class will handle
                    // the actual download and does not use this value.
                    .setSizeBytes(1)
                    .setIsReadSeekEfficient(true)
                    .setResourceId(new FTPFileResourceId((String)item));
            return MatchResult.create(MatchResult.Status.OK, Collections.singletonList(ret.build()));
        }).collect(Collectors.toList());
    }

    @Override
    protected ReadableByteChannel open(ResourceId resourceId) throws IOException {
        LOG.debug("Attempting to download FTP file: {}", resourceId);

        @SuppressWarnings("resource")
        FTPFileResourceId ftpResource = (FTPFileResourceId) resourceId;
        MyFTPClient ftpclient = new MyFTPClient();
        ftpclient.connect(ftpResource.getFTPServer());
        ftpclient.enterLocalPassiveMode();
        ftpclient.login("anonymous", "");
        int reply = ftpclient.getReplyCode();
        if (!FTPReply.isPositiveCompletion(reply)) {
            LOG.error("Could not connect to FTP server {}", ftpResource.getFTPServer());
            throw new IOException(String.format("Could not connect to FTP server %s", ftpResource.getFTPServer()));
        }

        return Channels.newChannel(ftpclient.retrieveFileStream(ftpResource.getFilename()));
    }

    @Override
    protected WritableByteChannel create(ResourceId resourceId, CreateOptions createOptions) throws IOException {
        throw new NotImplementedException();
    }

    @Override
    protected void copy(List srcResourceIds, List destResourceIds) throws IOException {
        throw new NotImplementedException();
    }

    @Override
    protected void rename(List srcResourceIds, List destResourceIds) throws IOException {
        throw new NotImplementedException();
    }

    @Override
    protected void delete(Collection resourceIds) throws IOException {
        throw new NotImplementedException();
    }

    @Override
    protected ResourceId matchNewResource(String singleResourceSpec, boolean isDirectory) {
        return new FTPFileResourceId(singleResourceSpec);
    }

    @Override
    protected String getScheme() {
        return "ftp";
    }

    /**
     * Custom specialization to make sure we always use BINARY mode.
     */
    private class MyFTPClient extends FTPClient {
        public InputStream retrieveFileStream(String remote) throws IOException {
            this.setFileType(BINARY_FILE_TYPE);
            return super.retrieveFileStream(remote);
        }
    }

}
