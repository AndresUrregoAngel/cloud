package com.ivadolabs.ac.noaa.ftp;

import com.google.auto.service.AutoService;
import org.apache.beam.repackaged.beam_sdks_java_extensions_google_cloud_platform_core.com.google.common.collect.ImmutableList;
import org.apache.beam.sdk.annotations.Experimental;
import org.apache.beam.sdk.io.FileSystem;
import org.apache.beam.sdk.io.FileSystemRegistrar;
import org.apache.beam.sdk.options.PipelineOptions;

import javax.annotation.Nullable;

@AutoService(FileSystemRegistrar.class)
@Experimental(Experimental.Kind.FILESYSTEM)
public class FTPFileSystemRegistrar implements FileSystemRegistrar {

    @Override
    public Iterable<FileSystem> fromOptions(@Nullable PipelineOptions options) {
        return ImmutableList.of(new FTPFileSystem());
    }
}
