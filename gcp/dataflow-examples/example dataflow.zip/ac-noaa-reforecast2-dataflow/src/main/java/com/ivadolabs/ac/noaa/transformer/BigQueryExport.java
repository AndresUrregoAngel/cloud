package com.ivadolabs.ac.noaa.transformer;

import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.TableRow;
import com.google.api.services.bigquery.model.TableSchema;
import com.ivadolabs.ac.noaa.domain.Statistic;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.io.gcp.bigquery.TableDestination;
import org.apache.beam.sdk.io.gcp.bigquery.WriteResult;
import org.apache.beam.sdk.transforms.*;
import org.apache.beam.sdk.transforms.windowing.CalendarWindows;
import org.apache.beam.sdk.transforms.windowing.IntervalWindow;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.TypeDescriptor;
import org.apache.beam.sdk.values.ValueInSingleWindow;
import org.joda.time.DateTimeZone;
import org.joda.time.Instant;
import org.joda.time.format.DateTimeFormat;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Transform custom tailored to export NOAA Reforecast2 Statistic to BigQuery. The data is pushed with a 'load_time'
 * (saved timestamp) so that if it ever runs multiple time for the same location/prediction we can pick the last
 * value when querying for data.
 *
 * The data is 'partitioned' (by table name only) using a different table per year. This code automatically creates
 * the table using the defined schema bellow.
 */
public class BigQueryExport extends PTransform<PCollection<Statistic>, WriteResult> {

    private static final String CSV_DATETIME_FORMAT = "yyyy-MM-dd HH:mm:00.000000";
    private static final DateFormat CSV_DATETIME_FORMATER = new SimpleDateFormat(CSV_DATETIME_FORMAT);
    private static final DateTimeFormatter CSV_ZONEDDATETIME_FORMATTER = DateTimeFormatter.ofPattern(CSV_DATETIME_FORMAT);

    private static final List<TableFieldSchema> SCHEMA_FIELDS = new LinkedList<>();
    static {
        SCHEMA_FIELDS.add(new TableFieldSchema().setName("airport").setType("STRING"));
        SCHEMA_FIELDS.add(new TableFieldSchema().setName("name").setType("STRING"));
        SCHEMA_FIELDS.add(new TableFieldSchema().setName("unit").setType("STRING"));
        SCHEMA_FIELDS.add(new TableFieldSchema().setName("analysis_date").setType("DATETIME"));
        SCHEMA_FIELDS.add(new TableFieldSchema().setName("valid_date").setType("DATETIME"));
        SCHEMA_FIELDS.add(new TableFieldSchema().setName("hrs_delta").setType("INT64"));
        SCHEMA_FIELDS.add(new TableFieldSchema().setName("latitude").setType("FLOAT64"));
        SCHEMA_FIELDS.add(new TableFieldSchema().setName("longitude").setType("FLOAT64"));
        SCHEMA_FIELDS.add(new TableFieldSchema().setName("value").setType("FLOAT64"));
        SCHEMA_FIELDS.add(new TableFieldSchema().setName("load_time").setType("DATETIME"));
    }
    private static final String TABLE_DESCRIPTION = "NOAA ReForecast2 predictions for year %s and for a sub-selection of airports.";


    private final String projectId;
    private final String datasetName;
    private final String tablePrefix;

    public BigQueryExport(String projectId, String datasetName, String tablePrefix) {
        this.projectId = projectId;
        this.datasetName = datasetName;
        this.tablePrefix = tablePrefix;
    }

    private String generateTargetTable(String year) {
        return String.format("%s:%s.%s%s", this.projectId, this.datasetName, this.tablePrefix, year);
    }

    private TableSchema generateSchema() {
        return new TableSchema().setFields(SCHEMA_FIELDS);
    }

    @Override
    public WriteResult expand(PCollection<Statistic> input) {
        // 1) Converts from Statistic to TableRow
        // 2) Gather data per window (defined by analysis date's year)
        // 3) Push data to BigQuery
        return input.apply(WithTimestamps.of(statistic -> new Instant(statistic.getAnalysisDate().toInstant().toEpochMilli())))
                .apply(
                        MapElements.into(TypeDescriptor.of(TableRow.class)).via(
                                (Statistic elem) -> new TableRow()
                                        .set("airport", elem.getLocation())
                                        .set("name", elem.getName())
                                        .set("unit", elem.getUnit())
                                        .set("analysis_date", CSV_ZONEDDATETIME_FORMATTER.format(elem.getAnalysisDate()))
                                        .set("valid_date", CSV_ZONEDDATETIME_FORMATTER.format(elem.getValidDate()))
                                        .set("hrs_delta", elem.getHoursDelta())
                                        .set("latitude", elem.getLatitude())
                                        .set("longitude", elem.getLongitude())
                                        .set("value", elem.getValue())
                                        .set("load_time", CSV_DATETIME_FORMATER.format(new Date()))
                        )
                )
                .apply(Window.into(CalendarWindows.years(1).withTimeZone(DateTimeZone.UTC)))
                .apply(BigQueryIO.writeTableRows()
                        .withSchema(generateSchema())
                        .to((SerializableFunction<ValueInSingleWindow<TableRow>, TableDestination>) value -> {
                            String yearString = DateTimeFormat.forPattern("yyyy").withZone(DateTimeZone.UTC)
                                    .print(((IntervalWindow) value.getWindow()).start());
                            return new TableDestination(
                                    generateTargetTable(yearString),
                                    String.format(TABLE_DESCRIPTION, yearString));
                        })
                        .withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND)
                        .withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
                );
    }


}
