package com.ivadolabs.ac.noaa.transformer;

import com.ivadolabs.ac.noaa.domain.GRIBFile;
import com.ivadolabs.ac.noaa.domain.Location;
import com.ivadolabs.ac.noaa.domain.Statistic;
import org.apache.beam.repackaged.beam_sdks_java_core.org.apache.commons.compress.utils.IOUtils;
import org.apache.beam.repackaged.beam_sdks_java_core.org.apache.commons.lang3.tuple.Triple;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ucar.grib.grib2.Grib2Data;
import ucar.grib.grib2.Grib2Input;
import ucar.grib.grib2.Grib2Record;
import ucar.unidata.io.RandomAccessFile;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.ZonedDateTime;
import java.util.*;

import static com.ivadolabs.ac.noaa.ReForecast2ExtractUtils.getLocations;

/**
 * Transform that extracts forecast values from the given GRIB2 files. This code expect the GRIB2 file to
 * follow the VERY SPECIFIC format of the Reforecast2 NOAA model (lots of forecast prediction of a single
 * statistics within the same file).
 *
 * See documentation here: <a href="https://www.esrl.noaa.gov/psd/forecasts/reforecast2/README.GEFS_Reforecast2.pdf">https://www.esrl.noaa.gov/psd/forecasts/reforecast2/README.GEFS_Reforecast2.pdf</a>
 */
public class GRIBExtractor extends PTransform<PCollection<KV<String, GRIBFile>>, PCollection<Statistic>> {

    private static final Logger LOG = LoggerFactory.getLogger(GRIBExtractor.class);

    // Using a large multiplier to make all Lat/Lon computation integer rather than floats
    private static final Integer GRIB_TO_DEG_UNIT = 1000000;

    // Using documented table to convert from statistic identifier to Unit. Data found within the GRIB2 file were unreliable for some statistics
    private static final Map<String, Triple<String, String, String>> UNITS_FROM_DOCUMENTATION = new HashMap<>();
    static {
        UNITS_FROM_DOCUMENTATION.put("pres_msl", Triple.of("Mean sea-level pressure", "Pa", "pres_msl"));
        UNITS_FROM_DOCUMENTATION.put("tmp_sfc", Triple.of("Skin temperature", "K", "tmp_sfc"));
        UNITS_FROM_DOCUMENTATION.put("tmp_bgrnd", Triple.of("Soil temperature", "K", "tmp_bgrnd"));
        UNITS_FROM_DOCUMENTATION.put("soilw_bgrnd", Triple.of("Volumetric soil moisture content 0.0 to 0.1 m depth", null, "soilw_bgrnd"));
        UNITS_FROM_DOCUMENTATION.put("weasd_sfc", Triple.of("Water equivalent of accumulated snow depth", "kg m-2", "weasd_sfc"));
        UNITS_FROM_DOCUMENTATION.put("tmp_2m", Triple.of("2-meter temperature", "K", "tmp_2m"));
        UNITS_FROM_DOCUMENTATION.put("spfh_2m", Triple.of("2-meter specific humidity", "kg kg-1 dry air", "spfh_2m"));
        UNITS_FROM_DOCUMENTATION.put("tmax_2m", Triple.of("Maximum temperature", "K", "tmax_2m"));
        UNITS_FROM_DOCUMENTATION.put("tmin_2m", Triple.of("Minimum temperature", "K", "tmin_2m"));
        UNITS_FROM_DOCUMENTATION.put("ugrd_10m", Triple.of("10-m u wind component", "ms-1", "ugrd_10m"));
        UNITS_FROM_DOCUMENTATION.put("vgrd_10m", Triple.of("10-m v wind component", "ms-1", "vgrd_10m"));
        UNITS_FROM_DOCUMENTATION.put("apcp_sfc", Triple.of("Total precipitation", "kg m-2", "apcp_sfc"));
        UNITS_FROM_DOCUMENTATION.put("watr_sfc", Triple.of("Water runoff", "kg m-2", "watr_sfc"));
        UNITS_FROM_DOCUMENTATION.put("lhtfl_sfc", Triple.of("Average surface latent heat net flux", "W m-2", "lhtfl_sfc"));
        UNITS_FROM_DOCUMENTATION.put("shtfl_sfc", Triple.of("Average sensible heat net flux", "W m-2", "shtfl_sfc"));
        UNITS_FROM_DOCUMENTATION.put("gflux_sfc", Triple.of("Average ground heat net flux", "W m-2", "gflux_sfc"));
        UNITS_FROM_DOCUMENTATION.put("suns_sfc", Triple.of("Sunshine", null, "suns_sfc"));
        UNITS_FROM_DOCUMENTATION.put("cape_sfc", Triple.of("Convective available potential energy", "J kg-1", "cape_sfc"));
        UNITS_FROM_DOCUMENTATION.put("cin_sfc", Triple.of("Convective inhibition", "J kg-1", "cin_sfc"));
        UNITS_FROM_DOCUMENTATION.put("pwat_eatm", Triple.of("Precipitable water", "kg m-2", "pwat_eatm"));
        UNITS_FROM_DOCUMENTATION.put("tcolc_eatm", Triple.of("Total-column integrated condensate", "kg m-2", "tcolc_eatm"));
        UNITS_FROM_DOCUMENTATION.put("tcdc_eatm", Triple.of("Total cloud cover", "%", "tcdc_eatm"));
        UNITS_FROM_DOCUMENTATION.put("dswrf_sfc", Triple.of("Downward short-wave radiation flux at the surface", "W m-2", "dswrf_sfc"));
        UNITS_FROM_DOCUMENTATION.put("dlwrf_sfc", Triple.of("Downward long-wave radiation flux at the surface", "W m-2", "dlwrf_sfc"));
        UNITS_FROM_DOCUMENTATION.put("uswrf_sfc", Triple.of("Upward short-wave radiation flux at the surface", "W m-2", "uswrf_sfc"));
        UNITS_FROM_DOCUMENTATION.put("ulwrf_sfc", Triple.of("Upward long-wave radiation flux at the surface", "W m-2", "ulwrf_sfc"));
        UNITS_FROM_DOCUMENTATION.put("ulwrf_tatm", Triple.of("Upward long-wave radiation flux at the top of the atmosphere", "W m-2", "ulwrf_tatm"));
        UNITS_FROM_DOCUMENTATION.put("pvort_isen", Triple.of("Potential vorticity on q = 320K isentropic surface", "K m2 kg-1 s-1", "pvort_isen"));
        UNITS_FROM_DOCUMENTATION.put("ugrd_pvor", Triple.of("U component on 2 PVU (1 PVU = 1 K m2 kg-1 s-1) isentropic surface", "ms-1", "ugrd_pvor"));
        UNITS_FROM_DOCUMENTATION.put("vgrd_pvor", Triple.of("V component on 2 PVU isentropic surface", "ms-1", "vgrd_pvor"));
        UNITS_FROM_DOCUMENTATION.put("tmp_pvor", Triple.of("Temperature on 2 PVU isentropic surface ", "K", "tmp_pvor"));
        UNITS_FROM_DOCUMENTATION.put("pres_pvor", Triple.of("Pressure on 2 PVU isentropic surface", "Pa", "pres_pvor"));
        UNITS_FROM_DOCUMENTATION.put("ugrd_80m", Triple.of("80-m u wind component", "ms-1", "ugrd_80m"));
        UNITS_FROM_DOCUMENTATION.put("vgrd_80m", Triple.of("80-m v wind component", "ms-1", "vgrd_80m"));
        UNITS_FROM_DOCUMENTATION.put("wmixe_80m", Triple.of("80-m wind power", null, "wmixe_80m"));
        UNITS_FROM_DOCUMENTATION.put("vvel_850", Triple.of("Vertical velocity at 850 hPa", "Pa s-1", "vvel_850"));
        UNITS_FROM_DOCUMENTATION.put("pres_sfc", Triple.of("Surface Pressure", "Pa", "pres_sfc"));
    }
    private static final Triple<String, String, String> NO_UNIT = Triple.of("None", null, null);

    @Override
    public PCollection<Statistic> expand(PCollection<KV<String, GRIBFile>> input) {
        try {
            return input.apply(ParDo.of(new ExtractStatistics(getLocations())));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    public static class ExtractStatistics extends DoFn<KV<String, GRIBFile>, Statistic> {

        private List<Location> locations;

        public ExtractStatistics(List<Location> locations) {
            this.locations = locations;
        }

        /**
         * This method gets invoked for each GRIBFile. It will go through the locations list and extract a prediction
         * value for each one found within the file (one record per forecast time).
         * @param c
         * @throws IOException error occurred while handling temporary local file or extracting data from the GRIB file
         */
        @ProcessElement
        public void processElement(ProcessContext c) throws IOException {
            KV<String, GRIBFile> gribFileEntry = c.element();

            try (AutoDeletingTempFile wrapper = new AutoDeletingTempFile()) {
                // Copy the byte[] to a local temporary file -- the library used to make sense of the GRIB2 format requires a local file
                IOUtils.copy(new ByteArrayInputStream(gribFileEntry.getValue().getContent()), new FileOutputStream(wrapper.getFile().toFile()));

                // Load the GRIB2 file
                RandomAccessFile raf = new RandomAccessFile(wrapper.getFile().toFile().getAbsolutePath(), "r");
                raf.order(RandomAccessFile.BIG_ENDIAN);
                Grib2Input g2i = new Grib2Input(raf);
                g2i.scan(false, false);
                Grib2Data g2d = new Grib2Data(raf);

                // loop through GRIB records
                List<Grib2Record> records = g2i.getRecords();
                records.forEach(record -> {
                    // loop through locations
                    locations.forEach(location -> {
                        try {
                            float data = interpolateValueAtLocation(location.getLatitude(), location.getLongitude(), record, g2d);
                            // Publish exported Statistic
                            c.output(Statistic.from(gribFileEntry.getValue(),
                                    location.getAirportCode(),
                                    UNITS_FROM_DOCUMENTATION.getOrDefault(gribFileEntry.getValue().getStatisticName(), NO_UNIT).getMiddle(),
                                    findPredictionDate(record),
                                    location.getLatitude(),
                                    location.getLongitude(),
                                    data));
                        } catch (IOException e) {
                            LOG.error(String.format("Error extracting prediction data from file: %s", gribFileEntry.getValue().getFileName()), e);
                        }
                    });

                });
            }
        }

        private static ZonedDateTime findPredictionDate(Grib2Record record) {
            GregorianCalendar calendar = (GregorianCalendar) GregorianCalendar.getInstance(TimeZone.getTimeZone("UTC"));
            calendar.setTimeInMillis(record.getId().getRefTime());
            calendar.add(Calendar.HOUR, record.getPDS().getForecastTime());
            return calendar.toZonedDateTime();
        }

        private static int degToUnits(double deg) { return (int)(deg* GRIB_TO_DEG_UNIT); }

        private static int longitude180toUnits(float longitude180) {
            return Math.floorMod(degToUnits(longitude180), degToUnits(360.0));
        }

        private float interpolateValueAtLocation(float lat, float lon, Grib2Record record, Grib2Data g2d) throws IOException {
            // =======================================================================================
            // The following code is **strongly** inspired from from another open source GRIB library.
            //   It basically find the prediction value from the 4 surrounding model prediction point,
            //   and does an interpolation of the value at the required latitude/longitude.
            // =======================================================================================

            // Find j indices of the grid points of the matrix containing the data that surround the
            // passed latitude lat
            int deltalat = degToUnits(record.getGDS().getGdsVars().getLa1()) - degToUnits(lat);
            int jidx1 = (int)Math.floor((float)deltalat / (float)degToUnits(record.getGDS().getGdsVars().getDy()));

            // Correct indices when end of the array dimension is reached
            if (jidx1 >= record.getGDS().getGdsVars().getNy() - 1) jidx1--;
            int jidx2 = jidx1 + 1;

            // Find i indices of the grid points of the matrix containing the data that surround the
            // passed longitude lon
            int firstPointLon = degToUnits(record.getGDS().getGdsVars().getLo1());
            if (firstPointLon >= degToUnits(180)) firstPointLon -= degToUnits(360);
            int deltalon = longitude180toUnits(lon) - firstPointLon;
            int iidx1 = (int)Math.floor((float)deltalon / (float)degToUnits(record.getGDS().getGdsVars().getDx()));

            // Correct indices when end of the array dimension is reached
            if (iidx1 >= record.getGDS().getGdsVars().getNx() - 1) iidx1--;
            int iidx2 = iidx1 + 1;

            float data[] = g2d.getData(record.getGdsOffset(), record.getPdsOffset(), record.getId().getRefTime());
            // Extract data of the four grid points surrounding the passed coordinate and calculate the
            // values represented by the data
            float val11 = data[(jidx1 * record.getGDS().getGdsVars().getNx() + iidx1)];
            float val12 = data[(jidx1 * record.getGDS().getGdsVars().getNx() + iidx2)];

            float val21 = data[(jidx2 * record.getGDS().getGdsVars().getNx() + iidx1)];
            float val22 = data[(jidx2 * record.getGDS().getGdsVars().getNx() + iidx2)];

            // Find latitudes of the grid points of the matrix containing the data that surround the
            // passed latitude lat
            int lat1 = degToUnits(record.getGDS().getGdsVars().getLa1() - jidx1 * record.getGDS().getGdsVars().getDy());
            int lat2 = degToUnits(record.getGDS().getGdsVars().getLa1() - jidx2 * record.getGDS().getGdsVars().getDy());

            // Find longitudes of the grid points of the matrix containing the data that surround the
            // passed longitude lon
            int lon1 = firstPointLon + iidx1 * degToUnits(record.getGDS().getGdsVars().getDx());
            int lon2 = firstPointLon + iidx2 * degToUnits(record.getGDS().getGdsVars().getDx());

            // Interpolate value belonging to the passed location
            float val1x = val11 + (val12-val11) * (longitude180toUnits(lon)-lon1) / (lon2-lon1);
            float val2x = val21 + (val22-val21) * (longitude180toUnits(lon)-lon1) / (lon2-lon1);
            return val1x + (val2x-val1x) * (degToUnits(lat)-lat1) / (lat2-lat1);
        }

    }

    /**
     * Utility class that handles auto-deletion of spot-temporary file.
     */
    public static class AutoDeletingTempFile implements AutoCloseable {
        private final Path file;

        public AutoDeletingTempFile() throws IOException {
            file = Files.createTempFile(null, null);
        }

        public Path getFile() {
            return file;
        }

        @Override
        public void close() throws IOException {
            Files.deleteIfExists(file);
        }
    }

}
