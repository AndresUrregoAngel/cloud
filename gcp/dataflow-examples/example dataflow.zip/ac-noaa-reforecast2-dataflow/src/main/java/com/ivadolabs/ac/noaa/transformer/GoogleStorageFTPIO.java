package com.ivadolabs.ac.noaa.transformer;

import com.ivadolabs.ac.noaa.domain.GRIBFile;
import org.apache.beam.repackaged.beam_sdks_java_core.com.google.common.io.ByteStreams;
import org.apache.beam.sdk.io.FileSystems;
import org.apache.beam.sdk.io.fs.MatchResult;
import org.apache.beam.sdk.io.fs.ResourceId;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.util.MimeTypes;
import org.apache.beam.sdk.util.StreamUtils;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.text.ParseException;

/**
 * Transform that download file from an FTP server. IT looks up in Google Storage to see if the file was already
 * pulled from FTP before attempting the FTP download. If downloaded from FTP, the file is pushed to Google
 * Storage.
 *
 * <b>Important:</b> This transform assumes the FTP URL will have the NOAA Reforecast2 format.
 * E.g. ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018121100/c00/latlon/XXX.grib2
 */
public class GoogleStorageFTPIO extends PTransform<PCollection<String>, PCollection<KV<String, GRIBFile>>> {

    private static final Logger LOG = LoggerFactory.getLogger(GoogleStorageFTPIO.class);

    private final String bucketName;
    private final String baseDirectory;

    public GoogleStorageFTPIO(String bucketName, String baseDirectory) {
        this.bucketName = bucketName;
        this.baseDirectory = baseDirectory;
    }

    @Override
    public PCollection<KV<String, GRIBFile>> expand(PCollection<String> input) {
        return input.apply(ParDo.of(new CheckGoogleStorageOrDownload(this)))
                .apply(ParDo.of(new PushToGoogleStorage(this)));
    }

    /**
     * Function that download file from either Google Storage or target FTP (in this order). It will set the "cached"
     * flag to true if the file was found from Google Storage.
     */
    public static class CheckGoogleStorageOrDownload extends DoFn<String, KV<String, GRIBFile>> {

        private GoogleStorageFTPIO parentTransform;

        public CheckGoogleStorageOrDownload(GoogleStorageFTPIO parentTransform) {
            this.parentTransform = parentTransform;
        }

        @ProcessElement
        public void processElement(ProcessContext c) throws IOException, ParseException {
            String filename = c.element();
            MatchResult match = FileSystems.match(filename);
            ResourceId resourceId = match.metadata().get(0).resourceId();

            byte[] dataFromGoogleStorage = lookupInGoogleStorage(filename);
            if (dataFromGoogleStorage != null) {
                LOG.info("Found {} from Google Storage {}", resourceId.getFilename(), parentTransform.bucketName);
                c.output(KV.of(resourceId.getFilename(),
                        GRIBFile.from(resourceId.getFilename(), dataFromGoogleStorage, true)));
            } else {
                try (InputStream inStream = Channels.newInputStream(FileSystems.open(resourceId))) {
                    LOG.info("Downloading {} from FTP server", resourceId.getFilename());
                    c.output(KV.of(resourceId.getFilename(),
                            GRIBFile.from(resourceId.getFilename(), StreamUtils.getBytesWithoutClosing(inStream), false)));
                } catch (ParseException e) {
                    throw new IOException("Error occurred while analyzing filename", e);
                }
            }
        }


        private byte[] lookupInGoogleStorage(String filename) throws IOException {
            // Read file
            MatchResult result = FileSystems.match(GoogleStorageFTPIO.generateGoogleStoragePath(filename, parentTransform.bucketName, parentTransform.baseDirectory));
            if (result.status() == MatchResult.Status.OK) {
                try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                     ReadableByteChannel readerChannel = FileSystems.open(GoogleStorageFTPIO.extractGoogleStorageFilename(filename, parentTransform.bucketName, parentTransform.baseDirectory));
                     WritableByteChannel writerChannel = Channels.newChannel(out)) {
                    ByteStreams.copy(readerChannel, writerChannel);
                    return out.toByteArray();
                }
            } else {
                return null;
            }

        }

    }

    /**
     * Function that pushes the byte[] to Google Storage if the "cached" flag is set to false (meaning the data was downloaded from FTP).
     */
    public static class PushToGoogleStorage extends DoFn<KV<String, GRIBFile>, KV<String, GRIBFile>> {

        private GoogleStorageFTPIO parentTransform;

        public PushToGoogleStorage(GoogleStorageFTPIO parentTransform) {
            this.parentTransform = parentTransform;
        }

        @ProcessElement
        public void processElement(ProcessContext c) throws IOException {
            KV<String, GRIBFile> element = c.element();
            // If file was downloaded, let's push a copy on our local Google Storage
            if (!element.getValue().isCached()) {
                LOG.info("Saving {} to Google Storage {}", element.getValue().getFileName(), parentTransform.bucketName);
                // Write file
                ResourceId gsResourceId = GoogleStorageFTPIO.extractGoogleStorageFilename(element.getValue().getFileName(), parentTransform.bucketName, parentTransform.baseDirectory);
                try (ByteArrayInputStream in = new ByteArrayInputStream(element.getValue().getContent());
                     ReadableByteChannel readerChannel = Channels.newChannel(in);
                     WritableByteChannel writerChannel = FileSystems.create(gsResourceId, MimeTypes.BINARY)) {
                    ByteStreams.copy(readerChannel, writerChannel);
                } catch (IOException e) {
                    throw e;
                }
            }
            c.output(c.element());
        }
    }


    private static String generateGoogleStoragePath(String filename, String bucketName, String baseDirectory) {
        // remove prefix "/Projects/Reforecast2/" leaving (for example): "2018/201812/2018121100/c00/latlon/tmax_2m_2018121100_c00.grib2"
        String gsPath = filename.substring(filename.indexOf("Reforecast2") + "Reforecast2/".length());
        // convert to ResourceId
        return String.format("gs://%s/%s/%s", bucketName, baseDirectory, gsPath);
    }

    private static ResourceId extractGoogleStorageFilename(String filename, String bucketName, String baseDirectory) {
        return FileSystems.matchNewResource(generateGoogleStoragePath(filename, bucketName, baseDirectory), false);
    }

}
