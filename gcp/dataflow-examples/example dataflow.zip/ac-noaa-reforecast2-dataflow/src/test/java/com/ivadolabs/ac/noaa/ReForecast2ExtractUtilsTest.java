package com.ivadolabs.ac.noaa;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(JUnit4.class)
public class ReForecast2ExtractUtilsTest {

    @Test
    public void testInputDateFormat() throws ParseException {
        assertThat(ReForecast2ExtractUtils.convertToCalendar("2018-12-07").get(Calendar.YEAR)).isEqualTo(2018);
        assertThat(ReForecast2ExtractUtils.convertToCalendar("2018-12-07").get(Calendar.MONTH)).isEqualTo(11);
        assertThat(ReForecast2ExtractUtils.convertToCalendar("2018-12-07").get(Calendar.DAY_OF_MONTH)).isEqualTo(7);
    }


    @Test
    public void testNOAAFilepathGenerator() throws ParseException, IOException, URISyntaxException {
        Stream<String> filepaths = ReForecast2ExtractUtils.filenameGenerator("2018-12-07", "2018-12-15");
        assertThat(filepaths.limit(20)).containsExactly(
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/tmp_2m_2018120700_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/tmax_2m_2018120700_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/tmin_2m_2018120700_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/tmp_sfc_2018120700_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/spfh_2m_2018120700_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/weasd_sfc_2018120700_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/ugrd_10m_2018120700_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/vgrd_10m_2018120700_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/apcp_sfc_2018120700_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/suns_sfc_2018120700_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/pwat_eatm_2018120700_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/tcdc_eatm_2018120700_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/pres_sfc_2018120700_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120800/c00/latlon/tmp_2m_2018120800_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120800/c00/latlon/tmax_2m_2018120800_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120800/c00/latlon/tmin_2m_2018120800_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120800/c00/latlon/tmp_sfc_2018120800_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120800/c00/latlon/spfh_2m_2018120800_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120800/c00/latlon/weasd_sfc_2018120800_c00.grib2",
                "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120800/c00/latlon/ugrd_10m_2018120800_c00.grib2"
        );
    }


}
