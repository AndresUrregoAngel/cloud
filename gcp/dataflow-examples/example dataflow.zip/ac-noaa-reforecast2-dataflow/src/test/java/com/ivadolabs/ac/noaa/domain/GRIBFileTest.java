package com.ivadolabs.ac.noaa.domain;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.text.ParseException;
import java.util.GregorianCalendar;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(JUnit4.class)
public class GRIBFileTest {

    @Test
    public void testGRIBFileParser() throws ParseException {

        String apcpSfc = "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/apcp_sfc_2018120700_c00.grib2";

        GRIBFile fileA = GRIBFile.from(apcpSfc, new byte[0], false);
        assertThat(fileA.getFileName()).isEqualTo(apcpSfc);
        assertThat(fileA.getAnalylsisDate()).isEqualTo(new GregorianCalendar(2018, 11, 7, 0, 0).getTime());
        assertThat(fileA.getStatisticName()).isEqualTo("apcp_sfc");
        assertThat(fileA.isCached()).isFalse();

        String tmax_2m = "ftp://ftp.cdc.noaa.gov/Projects/Reforecast2/2018/201812/2018120700/c00/latlon/tmax_2m_2018120700_c00.grib2";

        GRIBFile fileB = GRIBFile.from(tmax_2m, new byte[0], true);
        assertThat(fileB.getFileName()).isEqualTo(tmax_2m);
        assertThat(fileB.getAnalylsisDate()).isEqualTo(new GregorianCalendar(2018, 11, 7, 0, 0).getTime());
        assertThat(fileB.getStatisticName()).isEqualTo("tmax_2m");
        assertThat(fileB.isCached()).isTrue();
    }


}
