#!/bin/bash

## Start Pipeline using Maven launcher
mvn compile exec:java -Dexec.mainClass=com.ivadolabs.ac.noaa.ReForecast2Extract  \
    -Dexec.args="--runner=DataflowRunner --project=ivadolabs-ac --tempLocation=gs://ivadolabs-ac-temp/tmp --startDate=2018-12-08 --endDate=2018-12-10"  \
    -Pdataflow-runner


